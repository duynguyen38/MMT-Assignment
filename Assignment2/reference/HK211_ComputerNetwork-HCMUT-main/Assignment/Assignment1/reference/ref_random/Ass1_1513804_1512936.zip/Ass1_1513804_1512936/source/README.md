# Video-Streaming-with-RTSP-and-RTP
Socket Programming in Python for video streaming with RTSP and RTP protocols.
Will update it soon.
